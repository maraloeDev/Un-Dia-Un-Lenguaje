/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase que gestiona las operaciones con la base de datos
 *
 * @author macarena
 */
public class GestorBD {

    public static Connection conn = null;
    public static String urlBD = "jdbc:mysql://localhost:3306/bocateria";

    /**
     * Obtiene la conexion a la base de datos
     *
     * @return Connection
     */
    public static Connection getConnection() {

        if (conn != null) {
            finalizarConexion();
        }
        try {            
            conn = (Connection) DriverManager.getConnection(urlBD, "root", "");;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return conn;
    }

    /**
     * Cierra la conexion con la base de datos si esta abierta y hace un commit
     * si procede.
     */
    public static void finalizarConexion() {
        if (conn != null) {
            try {            
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }       
    }

    /**
     * Devuelve un Resultset con el resultado de la consulta
     *
     * @return ResultSet
     */
    public static ResultSet consulta() {
        Connection con = null;
        ResultSet rs = null;
        try {
            con = GestorBD.getConnection();            
            String sql="SELECT columnas FROM tabla WHERE columna = valor";
            PreparedStatement pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } 
        return rs;
    }    
   

    /**
     * Devuelve el numero de filas afectadas por la consulta.
     *
     * @return Int
     */
    public static Integer insertar() {
        Connection con = null;
        int resultado = -1;
        try {
            con = GestorBD.getConnection();
            String sql="INSERT INTO tabla (columnas) VALUES (valores)";
            PreparedStatement ps = con.prepareStatement(sql);
            //...                 
            resultado = ps.executeUpdate();            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            finalizarConexion();
        }
        return resultado;
    }
    

    /**
     * Devuelve el numero de filas afectadas por la consulta.
     *
     * @return Int
     */
    public static Integer actualizar() {
        Connection con = null;
        int resultado = -1;
        try {
            con = GestorBD.getConnection();
            String sql="UPDATE tabla SET columna = valor WHERE columna = valor";
            PreparedStatement ps = con.prepareStatement(sql);
            //...                 
            resultado = ps.executeUpdate();            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            finalizarConexion();
        }
        return resultado;
    }
}
