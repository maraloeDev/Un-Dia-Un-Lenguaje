package solucion;

import java.time.LocalDate;

public class Usuario {

    //atributos
    private static int cont = 0;   //contador estático para generar el ID autonumérico y único para cada usuario 
    private int ID;
    private String nombre;
    private String password;
    private LocalDate fecha;
    private double cuota;
    private boolean bloqueado;

    //constructores    
    public Usuario(String nombre) {
        this.ID = ++cont; //generamos el ID de forma correlativa
        this.nombre = nombre;
        this.password = "";
        this.fecha = LocalDate.now();
        this.cuota = 100.0;
        this.bloqueado = false;
    }

    public Usuario() {
        this.ID = ++cont; //generamos el ID de forma correlativa
        this.nombre = "";
        this.password = "";
        this.fecha = null;
        this.cuota = 0;
        this.bloqueado = false;
    }

    //getter
    public int getID() {
        return ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPassword() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public double getCuota() {
        return cuota;
    }

    //setter
    public void setPassword(String password) {
        this.password = password;
    }

    public void setCuota(double cuota) {
        this.cuota = cuota;
    }

    public boolean isBloqueador() {
        return bloqueado;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }

    //Metodos
    public String ocultarPassword(char caracter) {
        String passwd = "";
        for (int i = 0; i < password.length(); i++) {
            passwd += caracter;
        }
        return passwd;
    }

    public void consumirCouta() {
        if (this.cuota > 0) {
            this.cuota -= 10.0;
        }
        if (this.cuota == 0) {
            this.bloqueado = true;
        }
    }

    @Override
    public String toString() {
        String indicador = (this.bloqueado == true) ? "(X) " : "";
        return indicador + nombre + "(" + ID + ") / " + password + ": " + cuota + " Mb";
    }

}
