package solucion;

public class AppUsuarios {
        
    public static void main(String[] args) {
        
        Usuario pepe=new Usuario();
        pepe.setNombre("Pepe");
        pepe.setPassword("pepito");
        
        System.out.println(pepe);
        
        Usuario marta=new Usuario("Marta");
        marta.setPassword("martita");
        marta.setCuota(2 * 1024);
        marta.setBloqueado(true);
        
        System.out.println(marta);
    }
}
