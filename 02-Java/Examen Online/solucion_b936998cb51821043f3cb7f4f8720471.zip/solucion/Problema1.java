package solucion;

import java.util.Scanner;

public class Problema1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int num;                        //número introducido por el usuario
        int cont = 0;                   //contador de números introducidos
        int mayor = Integer.MIN_VALUE;  //mayor de los números introducidos
                                        //le damos el menor valor posible 
                                        //para que la 1ª vez sea el primer número introducido
                                        //con el que empezar a comparar el resto
        int sumaMultiplos = 0;          //acumula la suma de los múltiplos de 5

        do {
            System.out.print("Introduce numero: ");
            num = sc.nextInt();

            //antes de realizar todo el proceso tenemos que comprobar si el número es distinto de 0
            //porque si es el caso no tenemos que realizar ningún procesamiento
            if (num != 0) { 
                cont++;

                if (num >= mayor) {
                    mayor = num;
                }
                if (num % 5 == 0) {
                    sumaMultiplos += num;
                }
            }
        } while (num != 0);

        System.out.println("> Números introducidos: " + cont);
        System.out.println("> Número mayor: " + mayor);
        System.out.println("> Suma de los multiplos de 5: " + sumaMultiplos);

    }

}
