package solucion;

import java.util.*;

public class Problema2 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        char resp = 0;          //respuesta del usuario a la pregunta de continuar tirando la moneda
        boolean lanzamiento;    //simula el valor de la moneda que ha salido al lanzarla
        //bucle de tiradas de la moneda
        do {
            lanzamiento = lanzarMoneda();
            if (lanzamiento == true) {
                System.out.println("Lanzamiento de la moneda: Cara");
            } else {
                System.out.println("Lanzamiento de la moneda: Cruz");
            }
            //bucle de validación de la respuesta a la pregunta de continuar
            do {
                System.out.print("¿Otra tirada (S/N)?:");
                resp = sc.next().toUpperCase().charAt(0);
                if (resp != 'S' && resp != 'N') {
                    System.out.println("Respuesta incorrecta. Inténtalo de nuevo");
                }
            } while (resp != 'S' && resp != 'N');

        } while (resp != 'N');

    }

    private static boolean lanzarMoneda() {
        Random r = new Random();
        return r.nextBoolean(); //true -> CARA false -> CRUZ
    }
}
