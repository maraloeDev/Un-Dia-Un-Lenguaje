package problema1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Macarena
 */

//1
public class Provincia implements Comparable<Provincia> {

    private String nombreProvincia;
    private String prefijo;

    public Provincia(String prefijo, String nombreProvincia) {
        this.prefijo = prefijo;
        this.nombreProvincia = nombreProvincia;
    }

    public String getNombreProvincia() {
        return nombreProvincia;
    }

    public String getPrefijo() {
        return prefijo;
    }

    public void setNombreProvincia(String nombreProvincia) {
        this.nombreProvincia = nombreProvincia;
    }

    public void setPrefijo(String prefijo) {
        this.prefijo = prefijo;
    }

    @Override
    public String toString() {
        return nombreProvincia;
    }

    @Override
    public int compareTo(Provincia o) {
        return this.getPrefijo().compareTo(o.getPrefijo());
    }

}
