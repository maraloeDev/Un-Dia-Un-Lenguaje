package problema1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 *
 * @author Macarena
 */
public class App {

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        
        Map<String, Provincia> mapa = new TreeMap<>();

        Provincia palencia = new Provincia("979", "Palencia");
        Provincia valladolid = new Provincia("983", "Valladolid");
        Provincia madrid = new Provincia("91", "Madrid");

        mapa.put(valladolid.getPrefijo(), valladolid);
        mapa.put(madrid.getPrefijo(), madrid);
        mapa.put(palencia.getPrefijo(), palencia);

        System.out.println(mapa);

        System.out.print("Prefio: ");
        String prefijo = sc.nextLine();

        Provincia provincia = mapa.get(prefijo);
        if (provincia == null) {
            System.out.println("Prefijo inexistente.");
        } else {
            System.out.println("Provincia: " + provincia);
        }

    }

}
