public class Carnet {

    private int codCarnet;
    private String titular;
    private int puntos;

    public Carnet(int codCarnet, String titular, int puntos) {
        this.codCarnet = codCarnet;
        this.titular = titular;
        this.puntos = puntos;
    }

    public int getCodCarnet() {
        return codCarnet;
    }

    public int getPuntos() {
        return puntos;
    }

    public String getTitular() {
        return titular;
    }

    @Override
    public String toString() {
        String cad = "";
        cad = "\nCodigo carnet: " + this.codCarnet;
        cad += "\nTitular: " + this.titular;
        cad += "\nPuntos: " + this.puntos + "\n";
        return cad;
    }

    public void quitarPuntos(int n) throws Exception {
        if (this.puntos < n) {
            throw new Exception("Puntos insuficientes");
        }
        puntos -= n;
    }

    public boolean retirado() {
        return (this.puntos == 0);
    }
}
